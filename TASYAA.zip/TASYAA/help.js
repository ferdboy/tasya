const help = (prefix) => { 
	return `

><><><><><><><><><><><
+ *TASYA BOT MENU* +
><><><><><><><><><><><
                 
➣ *${prefix}info*
➣ *${prefix}donasi*
➣ *${prefix}owner*
➣ *${prefix}speed*
➣ *${prefix}report [lapor bug]*

🔰 *MEDIA* 🔰

➢ *${prefix}sticker*
➢ *${prefix}stickergif*
➢ *${prefix}tsticker*
➢ *${prefix}toimg*
➢ *${prefix}tomp3*
➢ *${prefix}pinterest*
➢ *${prefix}quotes*
➢ *${prefix}nulis*
➢ *${prefix}ocr*
➢ *${prefix}ytsearch*
➢ *${prefix}ytmp3*
➢ *${prefix}tomp3*
➢ *${prefix}ytmp4*
➢ *${prefix}tiktok*
➢ *${prefix}tiktokstalk*
➢ *${prefix}fototiktok*
➢ *${prefix}igstalk*
➢ *${prefix}image*
➢ *${prefix}tts*
➢ *${prefix}tes*
➢ *${prefix}tep*
➢ *${prefix}ttp*
➢ *${prefix}meme*
➢ *${prefix}memeindo*
➢ *${prefix}ssweb*
➢ *${prefix}inu*
➢ *${prefix}unta*
➢ *${prefix}anjing*
➢ *${prefix}playstore*zssyaz,
➢ *${prefix}url2image*
➢ *${prefix}kbbi*
➢ *${prefix}imoji*
➢ *${prefix}wait*

 🔰 *MAKER* 🔰

➣ *${prefix}glitch <teks|teks>*
➣ *${prefix}phlogo <teks|teks>*
➣ *${prefix}wolflogo <teks|teks>*
➣ *${prefix}wolflogo2 <teks|teks>*
➣ *${prefix}quotemaker <tx|wtrmk|tema>*
➣ *${prefix}daun* _nama_
➣ *${prefix}bpink* _nama_
➣ *${prefix}textdark* _nama_
➣ *${prefix}textblue* _nama_
➣ *${prefix}stiltext*
➣ *${prefix}ninjalogo* teks|teks
➣ *${prefix}party*
➣ *${prefix}rtext*
➣ *${prefix}water* _nama_
➣ *${prefix}lionlogo <teks|teks>*
➣ *${prefix}textscreen*
➣ *${prefix}text3d*
➣ *${prefix}light*
➣ *${prefix}marvelogo <teks|teks>*
➣ *${prefix}snow <teks|teks>*
➣ *${prefix}firetext*

 🔰 *FUN&GAMES* 🔰

➢ *${prefix}truth*
➢ *${prefix}dare*
➢ *${prefix}tebakgambar*
➢ *${prefix}game*
➢ *${prefix}primbonjodoh*
➢ *${prefix}ramaljadian*
➢ *${prefix}mlherolist*
➢ *${prefix}bucin*
➢ *${prefix}persengay*
➢ *${prefix}ramalhp <nomor>*
➢ *${prefix}ceckjodoh*
➢ *${prefix}spamcall* 821xxxx

🔰 *ANIME* 🔰

➣ *${prefix}anime*
➣ *${prefix}nekonime*
➣ *${prefix}neonime*
➣ *${prefix}animehug*
➣ *${prefix}animecry*
➣ *${prefix}loli*
➣ *${prefix}loli2*
➣ *${prefix}waifu*
➣ *${prefix}waifu2*
➣ *${prefix}waifu3*
➣ *${prefix}wibu*
➣ *${prefix}randomanime*
➣ *${prefix}pokemon*
➣ *${prefix}artinama*

🔰 *INFO DAN EDUKASI* 🔰

➢ *${prefix}jadwaltvnow*
➢ *${prefix}infogc*
➢ *${prefix}quran*
➢ *${prefix}infogempa*
➢ *${prefix}beritahoax*
➢ *${prefix}covid*
➢ *${prefix}jsholat* _wilayah_
➢ *${prefix}infogithub*
➢ *${prefix}cuaca*
➢ *${prefix}trendtwit*
➢ *${prefix}infonomor*
➢ *${prefix}infomobil*
➢ *${prefix}infomotor*
➢ *${prefix}grupinfo*
➢ *${prefix}lirik*
➢ *${prefix}quotes*
➢ *${prefix}cerpen*
➢ *${prefix}chord*
➢ *${prefix}wiki*
➢ *${prefix}brainly*
➢ *${prefix}resepmasakan*
➢ *${prefix}map*

🔰 *GRUP* 🔰

➢ *${prefix}ownergrup*
➣ *${prefix}add*
➣ *${prefix}kick*
➣ *${prefix}kickbot*
➣ *${prefix}afk*
➣ *${prefix}promote*
➣ *${prefix}demote*
➣ *${prefix}setname*
➣ *${prefix}setdesc*
➣ *${prefix}welcome*
➣ *${prefix}nsfw*
➣ *${prefix}simih*
➣ *${prefix}grup [buka/tutup]*
➣ *${prefix}tagme*
➣ *${prefix}hidetag*
➣ *${prefix}tagall*
➣ *${prefix}otagall*
➣ *${prefix}fitnah*
➣ *${prefix}infogc*
➣ *${prefix}grupinfo*
➣ *${prefix}linkgrup*
➣ *${prefix}listadmins*
➣ *${prefix}openanime*
➣ *${prefix}edotense*

🔰 *NSFW* 🔰

➢ *${prefix}nsfwloli*
➢ *${prefix}nsfwblowjob*
➢ *${prefix}nsfwneko*
➢ *${prefix}nsfwtrap*
➢ *${prefix}randomhentai*
➢ *${prefix}hentai*
➢ *${prefix}indohot*

🔰 *KERANG AJAIB* 🔰

➣ *${prefix}apakah*
➣ *${prefix}kapankah*
➣ *${prefix}bisakah*
➣ *${prefix}rate*
➣ *${prefix}watak*
➣ *${prefix}hobby*

🔰 *OTHER* 🔰

➢ *${prefix}blocklist*
➢ *${prefix}testime*
➢ *${prefix}hilih*
➢ *${prefix}say*
➢ *${prefix}delete*
➢ *${prefix}shorturl*

 🔰 *OWNER* 🔰

➣ *${prefix}bc*
➣ *${prefix}ban*
➣ *${prefix}block*
➣ *${prefix}unblock*
➣ *${prefix}clearall*
➣ *${prefix}clone*
➣ *${prefix}getses*
➣ *${prefix}setpp*
➣ *${prefix}setpp*
➣ *${prefix}leave*
➣ *${prefix}kudeta*

><><><><><><><><><><><><><
*POWERED BY FERDI ARDIAN*
><><><><><><><><><><><><><`
}
exports.help = help
